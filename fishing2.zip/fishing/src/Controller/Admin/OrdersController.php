<?php

namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\ORM\Table;
use Cake\ORM\TableRegistry;

class OrdersController extends AppController {
   

    public function index() {

        $this->set('title', "Order List");        
        $this->viewBuilder()->layout('admin');
        $this->UserAddresses = TableRegistry::get("UserAddresses");
        $conditions = array();
        $limit = 10;

        if (isset($_GET['q']) && !empty($_GET['q'])) {
            $conditions['or']['Products.name like'] = "%" . trim($_GET['q']) . "%";
        }
        if (isset($_GET['limit']) && !empty($_GET['limit'])) {
            $limit = $_GET['limit'];
        }

        $this->paginate = [
            'limit' => $limit,
            'conditions' => $conditions,
            'order' => [
                'Orders.id' => 'desc'
            ],
//            'contain' => ['Users', 'OrderItems', 'OrderItems.products']
             'contain' => ['OrderItems','Users','OrderItems.Products']
        ];

        $orders = $this->paginate();        

        $this->set('orders', $orders);
        $user_ids = array();
        foreach ($orders as $order) {
            $user_ids[] = $order->user_id;
            $address_id=$order->order_address_id;           
            $address[$order->id] = $this->UserAddresses->find('all',array('conditions'=> ['UserAddresses.id'=>$address_id]))->first();
        }  
        $this->set('address', $address);
        $statuses = $this->__getOrderStatus();
        $this->set('statuses', $statuses);
    }
    public function changeOrderitemStatus($id = null, $status = null) {
        $this->OrderItems = TableRegistry::get("OrderItems");
        $this->Users = TableRegistry::get("Users");
        $this->viewBuilder()->layout('ajax');
        $query = $this->OrderItems->query();
        $query2 = $this->Order->query();
         if($status=='Confirmed'){
            $result=$query->update()
                ->set(['status' => $status])
                ->where(['id' => $id])
                ->execute();
            $result2=$query2->update()
                ->set(['invoice' => 1])
                ->where(['id' => $id])
                ->execute();
            $orderitems=$this->OrderItems->get($id);
            $order=$this->Orders->get($orderitems->order_id);
            $user=$this->Users->get($order->user_id);
            $link=$this->request->webroot."/invoice/".$order->id;
            $emailregister="Hello,".$user->name."<br/>Your Order status changed to ".$status.".<br/> Your invoice for orderno #".$order->order_no." generated successfully! <br/> Invoice Link : ".$link;  
            $this->Mailer->send_php_mail($user->username,"Invoice For Order",$emailregister);
         }
        if( $status=='In Transist' || $status=='In Transist' || $status=='Shipped' || $status=='Handover' || $status=='Completed' || $status=='Delivered'){
            $result=$query->update()
                ->set(['status' => $status])
                ->where(['id' => $id])
                ->execute();
            $result2=$query2->update()
                ->set(['invoice' => 1])
                ->where(['id' => $id])
                ->execute();
                $orderitems=$this->OrderItems->get($id);
                $order=$this->Orders->get($orderitems->order_id);
                $user=$this->Users->get($order->user_id);
                $link=$this->request->webroot."/invoice/".$order->id;
                $emailregister="Hello,".$user->name."<br/> Your Order status changed to ".$status.". Please check your invoice! <br/> Invoice Link : ".$link;  
                $this->Mailer->send_php_mail($user->username,"Invoice For Order",$emailregister);
        }else{        
        $result=$query->update()
                ->set(['status' => $status])
                ->where(['id' => $id])
                ->execute();
        $result2=$query2->update()
                ->set(['invoice' => 0])
                ->where(['id' => $id])
                ->execute();
                $orderitems=$this->OrderItems->get($id);
                $order=$this->Orders->get($orderitems->order_id);
                $user=$this->Users->get($order->user_id);
                $link=$this->request->webroot."/invoice/".$order->id;
                $emailregister="Hello,".$user->name."<br/> Your Order status changed to ".$status;  
                $this->Mailer->send_php_mail($user->username,"Invoice For Order",$emailregister);
       } 
        if (!empty($id) && !empty($status))
            echo "Order Item status has been changed.";
        else
            echo "Error occured. Please try again after sometime.";
        exit;
    }

}