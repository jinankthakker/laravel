<?php

// src/Model/Table/ArticlesTable.php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\ORM\TableRegistry;
use App\Model\Table\AppTable;

class TestimonialsTable extends AppTable {

    public function initialize(array $config) {
        parent::initialize($config);
        $this->belongsTo('Users');
       }
}
