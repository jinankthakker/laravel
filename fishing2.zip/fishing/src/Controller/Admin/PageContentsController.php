<?php
namespace App\Controller\Admin;

use App\Controller\AppController;

class PagecontentsController extends AppController{

	public function index(){
		  $this->set('title', "Page Contents");
	        $this->viewBuilder()->layout('admin');
	        $limit = 10;
	        $conditions = array();

	        if (isset($_GET['q']) && !empty($_GET['q'])) {
	            $q = $_GET['q'];
	            $int_q = preg_replace('/\D/', '', $q);
	            $int_q = (!empty($int_q)) ? number_format($int_q) : "";
	            $conditions['or']['Pagecontents.name like'] = "%" . trim($q) . "%";            
	            }            
	        if (isset($_GET['limit']) && !empty($_GET['limit'])) {
	            $limit = $_GET['limit']; 
	        } 
	        $this->paginate = [
	            'limit' => $limit,
	            'conditions' => $conditions,
	            'order' => [
	                'Pagecontents.id' => 'asc'
	            ],
	            'contain' => ['Categories']
	            
	        ];

	        $pagecontents = $this->paginate();//        
	        $this->set('pagecontents', $pagecontents);
	}
	public function add() {
	        $this->set('title', "Add Page Contents");
	        $this->viewBuilder()->layout('admin');	       
	        if ($this->request->is('post')) {	        	
	            if ($this->Products->saveData($this->request->data)) {
	                $this->Flash->success(__('The Page Contents has been saved.'));
	                return $this->redirect(['action' => 'index']);
	            }else{
	            $this->Flash->error(__('Unable to add  Page Contents.'));
	        	}
	        }	      
	         $pagecontents = $this->Pagecontents->newEntity(); 
	        $this->set('pagecontents', $pagecontents);	
	        $categories = $this->__getCategories();
        	$this->set('categories', $categories);      
	    }

	    public function edit($id = null) {
        $this->set('title', "Edit Page Contetns");
        $this->viewBuilder()->layout('admin');
        $pagecontent = $this->Pagecontents->get($id);
        if ($this->request->is(['post', 'put'])) {
            $data = $this->request->data;
            if ($this->Pagecontents->saveData($data)) {
                $this->Flash->success(__('Your channel has been updated.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('Unable to update your channel.'));
        }

        $this->set('pagecontent', $pagecontent);

        $categories = $this->__getCategories();
        $this->set('categories', $categories);
    }
}