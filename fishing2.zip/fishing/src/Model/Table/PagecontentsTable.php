<?php

// src/Model/Table/ArticlesTable.php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\ORM\TableRegistry;
use App\Model\Table\AppTable;

class PagecontentsTable extends AppTable {

    public function initialize(array $config) {
        parent::initialize($config);
        $this->belongsTo('Categories');
       }   

      public function saveData($data) {
        $pagecontents = $this->newEntity();
        foreach ($data as $key => $value) {
            $pagecontents->{$key} = $value;
        }
        if ($this->save($pagecontents))
            return 1;
        else
            return 0;
    } 

}

?>