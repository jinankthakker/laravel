<?php

namespace App\Controller\Admin;

use App\Controller\AppController;

class TestimonialsController extends AppController{

public function index() {
        $this->set('title', "Testimonials");
        $this->viewBuilder()->layout('admin');
        $limit = 10;
        $conditions = array();

        if (isset($_GET['q']) && !empty($_GET['q'])) {
            $conditions['or']['Users.name like'] = "%" . trim($_GET['q']) . "%";            
        }
        if (isset($_GET['limit']) && !empty($_GET['limit'])) {
            $limit = $_GET['limit'];
        }        

        $this->paginate = [
            'limit' => $limit,
            'conditions' => $conditions,
            'order' => [
                'Testimonials.id' => 'asc'
            ],
             'contain' => ['Users']           
        ];

        $testimonials = $this->paginate();      
        $this->set('testimonials', $testimonials);
    }
     public function activedeactive($id = null, $state = null) {
         $this->viewBuilder()->layout('ajax');
        $testimonial = $this->Testimonials->get($id);      
        $testimonialData['active'] = ($state === 'true' ) ? 1 : 0;   
        $this->Testimonials->patchEntity($testimonial, $testimonialData);

        if ($result = $this->Testimonials->save($testimonial)) {
            if ($state == "true")
                echo "Testimonial has been Activated.";
            else
                echo "Testimonial has been Deactivated.";
            exit;
        }
        else {
            echo 'Error';
            exit;
        }
    }

}
