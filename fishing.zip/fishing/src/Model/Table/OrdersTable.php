<?php

// src/Model/Table/ArticlesTable.php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\ORM\TableRegistry;
use App\Model\Table\AppTable;

class OrdersTable extends AppTable {

    public function initialize(array $config) {
        parent::initialize($config);
        $this->belongsTo('Users');
        $this->hasMany('OrderItems');
        /*$this->hasMany('UserAddresses', [
            'className' => 'UserAddresses',
            'conditions' => ['UserAddresses.id'=>'Orders.order_address_id']
        ]);*/
    }

    public function saveData($data) {
        $orders = $this->newEntity();
        foreach ($data as $key => $value) {
            $orders->{$key} = $value;
        }
        $result=$this->save($orders);
        return $result->id;
    }

}

?>