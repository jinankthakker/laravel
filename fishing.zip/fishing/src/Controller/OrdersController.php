<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\Auth\DefaultPasswordHasher;
use Cake\Core\Configure;
use Cake\ORM\Table;
use Cake\ORM\TableRegistry;
use Cake\Utility\Hash;
class OrdersController extends AppController{

    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $this->Auth->allow(['registration']);
    }

    public function myorder(){
      if($this->Auth->user('is_register')==1){
        $this->set('title', "myaccount");
        $this->viewBuilder()->layout('front_layout'); 
        $this->UserAddresses = TableRegistry::get("UserAddresses");
        $this->OrderItems = TableRegistry::get("OrderItems");   
        $this->Colors = TableRegistry::get("Colors");        
        $colors=$this->Colors->find('list')->toArray();
        $this->set('colors', $colors);  
        $limit=5;
        $conditions=['Orders.user_id'=>$this->Auth->user('id'),'Orders.status !='=>'NULL'];
        $this->paginate = [
            'limit' => $limit,
            'conditions' => $conditions,
            'order' => [
                'Orders.id' => 'desc'
            ],
//            'contain' => ['Users', 'OrderItems', 'OrderItems.products']
             'contain' => ['OrderItems','Users','OrderItems.Products']
        ];

        $orders = $this->paginate();            
        $this->set('orders',$orders);
        $user_ids = array();
        if(!$orders->isEmpty()){
          foreach ($orders as $order) {
              $user_ids[] = $this->Auth->user('id');
              $address_id=$order->order_address_id;           
              $address[$order->id] = $this->UserAddresses->find('all',array('conditions'=> ['UserAddresses.id'=>$address_id]))->first();
          }      
          $this->set('address', $address);
        }    
        $statuses = $this->__getOrderStatus();
        $this->set('statuses', $statuses);
      }else{
        return $this->redirect(['controller'=>'pages','action' => 'index']);
      }

    }
    public function changeorderitemstatus($id = null,$name = null) {
        $this->OrderItems = TableRegistry::get("OrderItems");
        
        $this->viewBuilder()->layout('ajax');
        $query = $this->OrderItems->query();
        $result=$query->update()
                ->set(['request_for_cancellation' =>1,'invoice'=>0])
                ->where(['id' => $id])
                ->execute();
        $query2=$this->Orders->query();
        $orderitems=$this->OrderItems->get($id);
        /*$result2=$query2->update()
                ->set(['invoice'=>0])
                ->where(['id' => $orderitems->order_id])
                ->execute(); */       
        $order=$this->Orders->get($orderitems->order_id);
        
        $emailregister="Hello,".$this->Auth->user('name')."<br/> You request for cancellation of order item product <b>".$name."</b> from  orderno #".$order->order_no." request for cancellation";
       $adminemailregister="Hello, Admin<br/> Your order item product <b>".$name."</b> from  orderno #".$order->order_no." request for cancellation ";
        if (!empty($id)){
           $this->Mailer->send_php_mail($this->Auth->user('username'),"Cancellation For Order",$emailregister);
          $this->Mailer->send_php_mail("customerservice@thefishgripandmore.com ","Cancellation For Order",$adminemailregister);
            echo "Your request for order cancellation submitted successfully!";
            exit;
          }
        else{
            echo "Error occured. Please try again after sometime.";
        exit;
      }
    }

     public function invoice($id){
      require_once(ROOT . DS.'vendor' . DS  . 'mpdf'. DS . 'mpdf.php');
      $this->set('title', "payCheckout");
      $this->viewBuilder()->layout('front_layout'); 
      $this->OrderItems = TableRegistry::get("OrderItems"); 
      $this->UserAddresses = TableRegistry::get("UserAddresses"); 
      $order=$this->Orders->findById($id)->toArray();
      if(empty($order) ){
        $this->Flash->success(__('Invoice does not exist.'));
        return $this->redirect(['controller'=>'pages','action' => 'index']);
      }  
      if($order[0]->invoice ==0) {
         $this->Flash->success(__('Invoice does not exist.'));
        return $this->redirect(['controller'=>'pages','action' => 'index']);
      }
      $this->set('order', $order);  
      $orderitems=$this->OrderItems->find('all',array('conditions'=>['OrderItems.order_id'=>$id,'OrderItems.status !='=>'Cancelled','OrderItems.status !='=>'Processing'],'contain'=>['Products']))->toArray();      
      if(count($orderitems)==0){
         $this->Flash->success(__('Invoice does not exist.'));
         return $this->redirect(['controller'=>'pages','action' => 'index']);
      }
      $this->set('orderitems', $orderitems);  
      $address=$this->UserAddresses->find('all',array('conditions'=>['UserAddresses.id'=>$order['0']->order_address_id]))->toArray();    
      $this->set('address', $address);   
    }  
}