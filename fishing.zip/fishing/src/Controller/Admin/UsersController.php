<?php

namespace App\Controller\Admin;

use App\Controller\AppController;

class UsersController extends AppController{

	public function login()
    {
        $this->set('title', "Fish Grip & More Login");
    	$this->viewBuilder()->layout('admin_login');
        if ($this->request->is('post')) {
            $user = $this->Auth->identify();           
            if ($user) {
                if($user['role_id']==2){                    
                    $this->Flash->error(__('Invalid username or password, try again'));
                    return $this->redirect($this->Auth->logout());
                }else{
                    $this->Auth->setUser($user);
                    /*$this->Mailer->send_php_mail($user['email'],"Login","Succeesfully Logged in");*/
                     $this->Flash->success(__('Login Succeesfully!.')); 
                    return $this->redirect($this->Auth->redirectUrl());
                }

            }
            else{
            $this->Flash->error(__('Invalid username or password, try again'));
            }
        }
    }
    public function logout()
    {
         $this->Flash->success(__('Logout Succeesfully!.'));
        return $this->redirect($this->Auth->logout());

        
    }
    public function index()
    {
        $this->set('title', "Customer");
        $this->viewBuilder()->layout('admin');               
        $conditions=array();
        $limit=10;
        if (isset($_GET['q']) && !empty($_GET['q'])) {
            $conditions['or']['Users.name LIKE'] = "%" . trim($_GET['q']) . "%";
        }

        if (isset($_GET['limit']) && !empty($_GET['limit'])) {
            $limit = $_GET['limit'];
        }
        $conditions['Users.role_id'] = 2;

        $this->paginate = [
            'limit' => $limit,
            'conditions' => $conditions,
            'order' => [
                'Users.id' => 'desc'
            ]
        ];

        $users = $this->paginate();
        $this->set('users', $users);
        
    }
    public function edit($id = null) {
        $this->set('title', "Edit User");
        $this->viewBuilder()->layout('admin');   
        $user = $this->Users->get($id);
        if ($this->request->is(['post', 'put'])) {

            $userData['name'] = $this->request->data['name'];
            $userData['bio'] = $this->request->data['bio'];

            $this->Users->patchEntity($user, $userData);

            if ($this->Users->save($user)) {
                $this->Flash->success(__('User details been updated.'));             
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('Unable to update user details.'));
            }
        }
        $this->set('user', $user);
    }
    public function details($id = null) {
         $this->viewBuilder()->layout('ajax');

        $user = $this->Users->get($id);
        $this->set('user', $user);
    }
    public function delete($id = null) {
        $this->viewBuilder()->layout('ajax');

        $entity = $this->Users->get($id);
        $result = $this->Users->delete($entity);

        echo "User has been successfully deleted.";
        exit;
    }
    public function activedeactive($id = null, $state = null) {
         $this->viewBuilder()->layout('ajax');
        $user = $this->Users->get($id);      
        $userData['active'] = ($state === 'true' ) ? 1 : 0;   
        $this->Users->patchEntity($user, $userData);

        if ($result = $this->Users->save($user)) {
            if ($state == "true")
                echo "User has been Activated.";
            else
                echo "User has been Deactivated.";
            exit;
        }
        else {
            echo 'hio';
            exit;
        }
    }
}