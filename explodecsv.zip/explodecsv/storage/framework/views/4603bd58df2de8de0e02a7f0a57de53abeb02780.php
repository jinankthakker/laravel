<?php $__env->startSection('content'); ?>
<div class="col-lg-12 main-chart">                  
  <div class="row">
  	<div class="col-lg-12">
        <div class="form-panel">
            <h4 class="mb"><i class="fa fa-angle-right"></i> Upload CSV file</h4>
            <form class="form-inline" method="post"  enctype="multipart/form-data" action="/upload/csv">
            <?php echo e(csrf_field()); ?>

              <div class="form-group">
                  <label class="sr-only" for="csv">Upload File</label>
                  <input type="file" name="csv" class="form-control" id="csv" >
              </div>              
              <input type="submit" class="btn btn-theme" value="upload">
            </form>
        </div>
    </div>

    <div class="col-lg-12">
        <div class="row mtbox">
        <?php if(!empty($files)): ?>
        <?php foreach($files as $key => $value): ?>
            <div class="col-md-2 col-sm-2 col-md-offset-1 box0">
                <div class="box1">
					<span class="li_news"></span>
					<h3><?php echo e($value->name); ?></h3>
                </div>
				
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>