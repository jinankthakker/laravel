<?php

namespace App\Controller\Component;

use Cake\Controller\Component;
use Cake\Core\Configure;
use Cake\Network\Email\Email;

Class MailerComponent extends Component {

    public $components = array('Session', 'Email');

    public function sendMail($to, $subject, $message, $from = null, $attachments = null, $emailCofig = 'default', $emailtemplate = 'default', $format = 'html', $replyto = null, $cc = 'dhavalnaphade5@gmail.com', $bcc = null) {

       /* $mail = $this->__send_php_mail($to, $from, $subject, $message);
        return $mail;*/

//        if (empty($from)) {
//            $from = Configure::read('FROM_EMAIL_ADDRESS');
//            $from_name = Configure::read('SITE_NAME');
//        }
//
//
//        $email = new Email('default');
//
//        $email->emailFormat($format);
//        if (isset($from_name))
//            $email->from(array($from => $from_name));
//        else
//            $email->from($from);
//
//        $email->to($to);
//        $email->cc($cc);
//        $email->bcc($bcc);
//        $email->replyTo($replyto);
//        $email->subject($subject);
//        $email->template($emailtemplate, 'default');
////        if ($_SERVER['SERVER_NAME'] == 'localhost') {
////            $email->transport('gmail');
////        }
//
//        if (!empty($attachments)) {
//            $email->attachments($attachments);
//        }
//
//        if ($email->send($message)) {
//            return true;
//        } else {
//            return false;
//        }
    }

    public function send_php_mail($to,$subject, $message) {
        $from = 'customerservice@thefishgripandmore.com';
        $_POST['req-email'] = $from;
      
        $headers = "From: " . strip_tags($_POST['req-email']) . "\r\n";
        $headers .= "Reply-To: customerservice@thefishgripandmore.com";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

        $mail = mail($to, $subject, $message, $headers);
        return $mail;
    }

}
