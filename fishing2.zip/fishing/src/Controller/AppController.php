<?php
/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link      http://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   http://www.opensource.org/licenses/mit-license.php MIT License
 */
namespace App\Controller;

use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\ORM\Table;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use Cake\ORM\Entity;
use Cake\Network\Exception\NotFoundException;

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @link http://book.cakephp.org/3.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller
{

    /**
     * Initialization hook method.
     *
     * Use this method to add common initialization code like loading components.
     *
     * e.g. `$this->loadComponent('Security');`
     *
     * @return void
     */
    public function initialize()
    {
        parent::initialize();

        $this->loadComponent('RequestHandler');
        $this->loadComponent('Flash');
        $this->loadComponent('Mailer');
         $this->loadComponent('Auth', [
            'loginRedirect' => [
                'controller' => 'dashboards',
                'action' => 'front'
            ],
            'logoutRedirect' => [
                'controller' => 'users',
                'action' => 'login'                
            ]
        ]);
        $this->loadComponent('Paginator');
        $loggeduser = $this->Auth->user();
        $this->set('loggeduser', $loggeduser);
        $categories_menu=$this->__getCategories();
        $this->set('categories_menu', $categories_menu);
        $cartItems=$this->_getCart();        
        $this->set('cartItems', $cartItems);
        $toEmail="info@altumcore.com";
        $this->set('toEmail', $toEmail);

    }

    /**
     * Before render callback.
     *
     * @param \Cake\Event\Event $event The beforeRender event.
     * @return void
     */
    public function beforeRender(Event $event)
    {
        if (!array_key_exists('_serialize', $this->viewVars) &&
            in_array($this->response->type(), ['application/json', 'application/xml'])
        ) {
            $this->set('_serialize', true);
        }
    }
    function __referer() {
        $referer_location = $this->request->session()->read('referer_location');
        $this->request->session()->write('referer_location', '');
        if ($referer_location == "/")
            $this->redirect(array("controller" => 'dashboards', 'action' => 'index'));
        else
            $this->redirect($referer_location);
    }
    function __getCategories() {
        $this->Categories = TableRegistry::get('Categories');
        $categories = $this->Categories->find('list')->where(array('Categories.is_active' => 1))->toArray();
        return $categories;
    }
    function __generate_order_id($id) {
        $characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
        $string = '';
         $max = strlen($characters) - 1;
         for ($i = 0; $i < $id; $i++) {
              $string .= $characters[mt_rand(0, $max)];
         }       
         return   $string;
    }     

    function _getCart(){
        $this->Carts = TableRegistry::get("Carts");
        $this->Products = TableRegistry::get("Products");
        if($this->Auth->user()){
            $carts=$this->Carts->find('all', ['conditions' => ['Carts.user_id' => $this->Auth->user('id')] ])->toArray();
            $total=0;
            $i=0;    
            if(empty($carts)){        
                foreach($carts as $key => $value) {                
                    $amount=$this->Products->find('all',['condtions'=>['Products.id'=>$value->product_id],'fields'=>['Products.price']])->toArray();                
                    $total=$total+$amount['price']*$value->qty;  
                    $i++; 
                }  
                 $cartItems['no']=$i;
                 $cartItems['amount']=$total;
                }else{
                    $cartItems['no']=0;
                    $cartItems['amount']=0;
                }
            }else{
                $cartItems=array();
                $cartItems['no']=0;
                $cartItems['amount']=0;
            }

        return $cartItems;       

    }
    function __getShippingAddresses($ids) {
        $user_shipping_addresses = array();
        $ids = array_unique($ids);
        if (!empty($ids)) {
            $this->UserAddresses = TableRegistry::get("UserAddresses");
            $user_addresses = $this->UserAddresses->find('all', [
                'conditions' => ['UserAddresses.user_id in' => $ids, 'type' => 'shipping']
            ]);
            foreach ($user_addresses as $user_address) {
                $user_shipping_addresses[$user_address->user_id] = $user_address->toArray();
            }
        }
        return $user_shipping_addresses;
    }

    function __storeOrderAddressId($order_id, $user_address_id) {
        $this->UserAddresses = TableRegistry::get("UserAddresses");
        $user_address = $this->UserAddresses->find('all', [
                    'conditions' => [ 'id' => $user_address_id]
                ])->first();

        $this->OrderAddresses = TableRegistry::get("OrderAddresses");
        $order_addresses_obj = array();
        $order_addresses_obj['order_id'] = $order_id;
        $order_addresses_obj['full_name'] = $user_address->full_name;
        $order_addresses_obj['phone'] = $user_address->phone;
        $order_addresses_obj['address1'] = $user_address->address1;
        $order_addresses_obj['address2'] = $user_address->address2;
        $order_addresses_obj['country'] = $user_address->country;
        $order_addresses_obj['landmark'] = $user_address->landmark;
        $order_addresses_obj['city'] = $user_address->city;
        $order_addresses_obj['state'] = $user_address->state;
        $order_addresses_obj['zipcode'] = $user_address->zipcode;
        $order_addresses_obj['type'] = $user_address->type;
        $OrderAddresses_id = $this->OrderAddresses->saveData($order_addresses_obj);

        $this->Orders = TableRegistry::get("Orders");
        $query = $this->Orders->query();
        $query->update()
                ->set(['order_address_id' => $OrderAddresses_id])
                ->where(['id' => $order_id])
                ->execute();

        return true;
    }

    function __updateField($tableObj, $fields, $where) {
        $this->{$tableObj} = TableRegistry::get($tableObj);
        $query = $this->{$tableObj}->query();
        $result = $query->update()
                ->set($fields)
                ->where($where)
                ->execute();
        return $result;
    }

    public function __curl_data($url, $fields, $is_json = false) {

        if ($is_json) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            curl_close($ch);
            return $response;
        }

        //url-ify the data for the POST
        $fields_string = "";
        foreach ($fields as $key => $value) {
            $fields_string .= $key . '=' . $value . '&';
        }
        rtrim($fields_string, '&');
        //open connection
        $ch = curl_init();

//set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

//execute post
        $result = curl_exec($ch);
//close connection
        curl_close($ch);

        return $result;
    }

    function __getOrderStatus() {

        if($this->Auth->user('role_id')==2){
            $statuses = array();
            $statuses['Cancelled'] = 'Cancelled';
        }else{
            $statuses = array();
            $statuses['Processing'] = 'Processing'; //1
            $statuses['Confirmed'] = 'Confirmed'; //2       
            $statuses['Handover'] = 'Handover'; //3
            $statuses['In-Transist'] = 'In Transist'; //4
            $statuses['Delivered'] = 'Delivered'; //5
            $statuses['Cancelled'] = 'Cancelled'; //6
            $statuses['Refunded'] = 'Refunded'; //7
            $statuses['Return'] = 'Return'; //8
            return $statuses;
        }
    }

    function __getOrderStatusById($id) {
        $statuses = array();
        $statuses['1'] = 'Processing'; //1
        $statuses['2'] = 'Confirmed'; //2       
        $statuses['4'] = 'Handover'; //3
        $statuses['5'] = 'In-Transist'; //4
        $statuses['6'] = 'Delivered'; //4
        $statuses['7'] = 'Cancelled'; //6
        $statuses['8'] = 'Refunded'; //7
        $statuses['9'] = 'Return'; //8
        return isset($statuses[$id]) ? $statuses[$id] : "Processing";
    }

    public function __getUniqGUID() {
        mt_srand((double) microtime() * 10000); //optional for php 4.2.0 and up.
        $charid = strtoupper(md5(uniqid(rand(), true)));
        $uuid = substr($charid, 0, 8)
                . substr($charid, 8, 4)
                . substr($charid, 12, 4)
                . substr($charid, 16, 4)
                . substr($charid, 20, 12)
                . time();

        return date("YmdHis") . "-" . strtolower($uuid);
    }

    public function __getMywishlistData() {
        $my_wishlist_data = array();
        if ($this->Auth->user('id')) {
            $conditions = array();
            $conditions['user_id'] = $this->Auth->user('id');
            $this->Wishlists = TableRegistry::get('Wishlists');
            $my_wishlist_data = $this->Wishlists->find('list', ['keyField' => 'product_id', 'valueField' => 'id', 'conditions' => $conditions])->toArray();
        }
        return $my_wishlist_data;
    }
}
