<?php
namespace App\Controller;
use Cake\Event\Event;
use Cake\Core\Configure;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\ORM\Table;
use Cake\ORM\TableRegistry;

class WishlistsController extends AppController{

    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $this->Auth->allow(['product', 'index']);
    }

	 public function index($id = null) {
        $this->set('title', "Wishlists");
        $this->viewBuilder()->layout('front_layout');
        $this->UserAddresses = TableRegistry::get("UserAddresses");  
        $this->Colors = TableRegistry::get("Colors");       
        $colors=$this->Colors->find('list')->toArray();
        $this->set('colors', $colors);
        $whish_item=$this->Wishlists->find('all',array('conditions'=>array('Wishlists.user_id'=>$this->Auth->user('id')),"contain"=>['Products']))->toArray();        
        $this->set('whish_item', $whish_item);
    }        
  
    public function addTowish($id=null,$qty=null,$color=null){
        $this->set('title', "Add To Cart");
        $this->viewBuilder()->layout('ajax');        
        $data['product_id']=$id;
        $data['qty']=$qty;
        $data['color']=$color;
        $data['user_id']=$this->Auth->user('id');
        if(empty($color)){
        $wishitems=$this->Wishlists->find('all',array('conditions'=>array('product_id'=>$id,'user_id'=>$this->Auth->user('id'))))->toArray();
        }else{
            $wishitems=$this->Wishlists->find('all',array('conditions'=>array('product_id'=>$id,'user_id'=>$this->Auth->user('id'),'color'=>$data['color'])))->toArray();
        }        
        if($wishitems) {            
           $data['id']=$wishitems[0]['id'];
           $data['qty']=$wishitems[0]['qty']+$qty;
           $wish=$this->Wishlists->saveData($data);
             echo $wish;exit;
           
        }else{
        
            $wish=$this->Wishlists->saveData($data);
            echo $wish;exit;
           
        }

    }

    public function updateQty($id,$qty){
        $this->set('title', "Wishlists");
      $this->viewBuilder()->layout('ajax');
          $data['id']=$id;
        $data['qty']=$qty;
           if($this->Wishlists->saveData($data)){
                echo $qty;
                exit;
           }
           exit;
    }

    public function deleteItem($id){
      $entity = $this->Wishlists->get($id);
      $result = $this->Wishlists->delete($entity);
      echo $result;
      exit;
    }

    
   
}