<!DOCTYPE html>
<html lang="en">
  <head>
    @include('theme.partials.head')
  </head>

  <body>

  <section id="container" >      
      <!--header start-->
      <header class="header black-bg">
          @include('theme.partials.header') 
      </header>
      <!--header end-->      
      
      <!--sidebar start-->
      <aside>
          @include('theme.partials.sidebar')
      </aside>
      <!--sidebar end-->     
     
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">

              <div class="row">
                  @yield('content')
              </div><! --/row -->
          </section>
      </section>

      <!--main content end-->
      <!--footer start-->
     <!--  <footer class="site-footer">
          @include('theme.partials.footer')
      </footer> -->
      <!--footer end-->
  </section>

           @include('theme.partials.script')
    <!-- js placed at the end of the document so the pages load faster -->
    
    @if(Session::has('messages'))
    <script>
    jQuery(document).ready(function() {
      @foreach(Session::get('messages') AS $msg)
      $.notify({
          title: '{{$msg['title']}}',
          message: '{{$msg['message']}}.'
        },{
          type: '{{$msg['type']}}'
        });       
      @endforeach
    });
    </script>
  @endif

  </body>
</html>
