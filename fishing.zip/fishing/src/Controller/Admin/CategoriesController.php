<?php
namespace App\Controller\Admin;

use App\Controller\AppController;

class CategoriesController extends AppController{

	public function index() {
        $this->set('title', "Categories");
        $this->viewBuilder()->layout('admin');
        $limit = 10;
        $conditions = array();

        if (isset($_GET['q']) && !empty($_GET['q'])) {
            $conditions['or']['Categories.name like'] = "%" . trim($_GET['q']) . "%";            
        }
        if (isset($_GET['limit']) && !empty($_GET['limit'])) {
            $limit = $_GET['limit'];
        }

        $conditions['Categories.is_delete'] = 0;

        $this->paginate = [
            'limit' => $limit,
            'conditions' => $conditions,
            'order' => [
                'Categories.id' => 'asc'
            ]            
        ];

        $categories = $this->paginate();      
        $this->set('categories', $categories);
    }
    public function add() {
        $this->set('title', "Add Category");
        $this->viewBuilder()->layout('admin');
        $category = $this->Categories->newEntity();
        if ($this->request->is('post')) {
            if (empty($this->request->data['parent_id']))
                $this->request->data['parent_id'] = 0;

            $this->request->data['is_active'] = 1;
            $data = $this->Categories->patchEntity($category, $this->request->data);
            if ($this->Categories->save($data)) {
                $this->Flash->success(__('The Category has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('Unable to add the Category.'));
        }
        $this->set('category', $category);       
    }


    public function edit($id = null) {
        $this->set('title', "Edit Category");
        $this->viewBuilder()->layout('admin');
        $category = $this->Categories->get($id);
        if ($this->request->is(['post', 'put'])) {           
            $this->Categories->patchEntity($category, $this->request->data);
            if ($this->Categories->save($category)) {
                $this->Flash->success(__('Category has been updated.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('Unable to update Category.Please try again after sometime.'));
        }

        $this->set('category', $category);
    }

    public function activedeactive($id = null, $state = null) {        
        $this->viewBuilder()->layout('ajax');
        $category = $this->Categories->get($id);      
        $categoryData['is_active'] = ($state === 'true' ) ? 1 : 0;   
        $this->Categories->patchEntity($category, $categoryData);

        if ($result = $this->Categories->save($category)) {
            if ($state == "true")
                echo "Catagory has been Activated.";
            else
                echo "Catagory has been Deactivated.";
            exit;
        }
        else {
            echo 'error!!';
            exit;
        }
    }

    public function delete($id = null) {
        $this->viewBuilder()->layout('ajax');
        $query = $this->Categories->query();
        $query->update()
                ->set(['is_delete' => 1])
                ->where(['id' => $id])
                ->execute();
        echo "Category has been successfully deleted.";
        exit;
    }

}