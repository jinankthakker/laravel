<?php

namespace App\Controller\Admin;

use App\Controller\AppController;

class SubscribersController extends AppController{

public function index() {
        $this->set('title', "Subscribers");
        $this->viewBuilder()->layout('admin');
        $limit = 10;
        $conditions = array();

        if (isset($_GET['q']) && !empty($_GET['q'])) {
            $conditions['or']['Subscribers.email like'] = "%" . trim($_GET['q']) . "%";            
        }
        if (isset($_GET['limit']) && !empty($_GET['limit'])) {
            $limit = $_GET['limit'];
        }        

        $this->paginate = [
            'limit' => $limit,
            'conditions' => $conditions,
            'order' => [
                'Subscribers.id' => 'asc'
            ]            
        ];

        $subscribers = $this->paginate();      
        $this->set('subscribers', $subscribers);
    }

}
