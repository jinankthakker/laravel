<?php
namespace App\Controller\Admin;

use App\Controller\AppController;

class ColorsController extends AppController{

	public function index(){
		  $this->set('title', "Colors");
	        $this->viewBuilder()->layout('admin');
	        $limit = 10;
	        $conditions = array();

	        if (isset($_GET['q']) && !empty($_GET['q'])) {
	            $q = $_GET['q'];
	            $int_q = preg_replace('/\D/', '', $q);
	            $int_q = (!empty($int_q)) ? number_format($int_q) : "";
	            $conditions['or']['Colors.name like'] = "%" . trim($q) . "%";            
	            }            
	        if (isset($_GET['limit']) && !empty($_GET['limit'])) {
	            $limit = $_GET['limit']; 
	        } 
	        $this->paginate = [
	            'limit' => $limit,
	            'conditions' => $conditions,
	            'order' => [
	                'Colors.id' => 'asc'
	            ],
	            
	        ];

	        $colors = $this->paginate();//        
	        $this->set('colors', $colors);
	}
	public function add() {
	        $this->set('title', "Add Color");
	        $this->viewBuilder()->layout('admin');
	        $colors = $this->Colors->newEntity();
	        if ($this->request->is('post')) {
	        	$data = $this->Colors->patchEntity($colors, $this->request->data);
	            if ($this->Colors->save($data)) {
	                $this->Flash->success(__('The Color has been saved.'));
	                return $this->redirect(['action' => 'index']);
	            }else{
	            $this->Flash->error(__('Unable to add the Color.'));
	        	}
	        }	       
	        $this->set('colors', $colors);	      
	    }
}