<?php
namespace App\Controller;
use Cake\Event\Event;
use Cake\Core\Configure;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\ORM\Table;
use Cake\ORM\TableRegistry;

class ProductsController extends AppController{

    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $this->Auth->allow(['product', 'index']);
    }

	 public function index($id = null) {
        $this->set('title', "Products");
        $this->viewBuilder()->layout('front_layout');
        $this->Pagecontents = TableRegistry::get("Pagecontents");
        $products=$this->Products->find('all',array('conditions'=>array('Products.category_id'=>$id,'Products.active'=>'1')));        
            $this->set('products', $products);
        $contents=$this->Pagecontents->find('all',array('conditions'=>array('Pagecontents.category_id'=>$id)))->toArray(); 
        $this->set('contents', $contents);
        $this->set('cat_id',$id);
    }
        
    public function product($id = null) {
        $this->set('title', "Product");
        $this->viewBuilder()->layout('front_layout');
        $this->ProductReviews = TableRegistry::get("ProductReviews");
        $this->Colors = TableRegistry::get("Colors");
        $product = $this->Products->find('all', [
                    'conditions' => ['Products.id' => $id],
                    'contain' => ['ProductColors']                   
                ])                
                ->toArray();        
        $this->set('product', $product); 
        $colors=$this->Colors->find('list')->toArray();
        $this->set('colors', $colors);          
        $relativeproducts=$this->Products->find('all',array('conditions'=>array('Products.category_id'=>$product[0]['category_id'],'NOT' => array(
            'Products.id' => $id ),'Products.active'=>'1')));        
        $this->set('relativeproducts', $relativeproducts);
        $reviews=$this->ProductReviews->find('all',['conditions'=>['ProductReviews.product_id'=>$id],'contain'=>['Users']]);
        $this->set('reviews', $reviews);
        $reviews_count=$this->ProductReviews->find('all',['conditions'=>['ProductReviews.product_id'=>$id],'contain'=>['Users']])->count();
        $this->set('reviews_count', $reviews_count);
        $review_check=$this->ProductReviews->find('all',['conditions'=>['ProductReviews.product_id'=>$id,'ProductReviews.user_id'=>$this->Auth->user('id')]])->first();
        $this->set('review_check', $review_check);
        if ($this->request->is('post')) {
            $Rdata=$this->request->data;
            $Rdata['product_id']=$id;
            $Rdata['user_id']=$this->Auth->user('id');
            $review=$this->ProductReviews->saveData($Rdata);  
            $this->Flash->success(__('Your Review Added Successfully!.')); 
            $this->redirect(array('controller'=>'products','action'=>'product',$id));

        }
    }
    public function addTocart($id=null,$qty=null,$color=null){
        $this->set('title', "Add To Cart");
        $this->viewBuilder()->layout('front_layout');
        $this->Carts = TableRegistry::get("Carts");
        $data['product_id']=$id;
        $data['qty']=$qty;
        $data['color']=$color;
        $data['user_id']=$this->Auth->user('id');
        if(empty($color)){
        $cartitems=$this->Carts->find('all',array('conditions'=>array('product_id'=>$id,'user_id'=>$this->Auth->user('id'))))->toArray();
        }else{
            $cartitems=$this->Carts->find('all',array('conditions'=>array('product_id'=>$id,'user_id'=>$this->Auth->user('id'),'color'=>$data['color'])))->toArray();
        }        
        if($cartitems) {            
           $data['id']=$cartitems[0]['id'];
           $data['qty']=$cartitems[0]['qty']+$qty;
           if($this->Carts->saveData($data)){
             $this->redirect(array('controller'=>'carts','action'=>'index'));
           }else{
                $this->redirect(array('controller'=>'products','action'=>'product',$id));
            }

        }else{
        
            if($this->Carts->saveData($data)){
                $this->redirect(array('controller'=>'carts','action'=>'index'));
            }else{
                $this->redirect(array('controller'=>'products','action'=>'product',$id));
            }
        }

    }

    public function emptyCart($c=null,$a=null,$id=null){
         $this->Carts = TableRegistry::get("Carts");
         if($this->Carts->deleteAll(
                [
                    'Carts.user_id' => $this->Auth->user('id'),                     
                ]));
            $this->redirect(array('controller'=>$c,'action'=>$a,$id));
    }
   
}