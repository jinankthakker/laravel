<?php

// src/Model/Table/ArticlesTable.php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\ORM\TableRegistry;
use App\Model\Table\AppTable;

class OrderAddressesTable extends AppTable {

    public function initialize(array $config) {
        parent::initialize($config);
//        $this->belongsTo('Products');
    }

    public function saveData($data) {
        $userAddresses = $this->newEntity();
        foreach ($data as $key => $value) {
            $userAddresses->{$key} = $value;
        }
        $result = $this->save($userAddresses);
        return $result->id;
    }

}

?>