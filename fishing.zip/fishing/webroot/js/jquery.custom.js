$(function () {
    $(".orderstatus").bind('click', function (event) {
        event.preventDefault();
        var thisobj = $(this);
        var order_item_id = thisobj.attr("data-id");
        var data_confirm_message = thisobj.attr("data-confirm");
        var data_status = thisobj.attr("data-status");
        var url = thisobj.attr("href");

        bootbox.confirm(data_confirm_message, function (result) {
            if (result == true) {
                url = url + "/" + order_item_id + "/" + data_status;
                window.location = url;
            }
        });
    });
});