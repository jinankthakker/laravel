<?php
 
namespace App\Http\Controllers;
 
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Validator;
use Request;
use Response;
use App\Csv;
use Session;
 
 
class UploadController extends Controller {
 
    public function index() {
       $files=Csv::get();       
        return view('theme.pages.upload',['files' => $files]);
    }

    public function uploadFiles() {
 
        // GET ALL THE INPUT DATA , $_GET,$_POST,$_FILES.
        
        // VALIDATION RULES       
        
           $file = Input::file('csv');;
          
           // SET UPLOAD PATH
            $destinationPath = 'assets/uploads';
            // GET THE FILE EXTENSION
            $extension = $file->getClientOriginalExtension();
            /*if($extension !="csv"){
                echo"error";
                exit;
            }*/
            // RENAME THE UPLOAD WITH RANDOM NUMBER
            $fileName = $file->getClientOriginalName();
            // MOVE THE UPLOADED FILES TO THE DESTINATION DIRECTORY
            $upload_success = $file->move($destinationPath, $fileName);
        
        // IF UPLOAD IS SUCCESSFUL SEND SUCCESS MESSAGE OTHERWISE SEND ERROR MESSAGE
        if ($upload_success) {
            $csv=new Csv();
            $csv->name=$fileName;
            $csv->save();
            return redirect('/upload')->with('messages', [
                [
                    'type' => 'success',
                    'title' => 'File Upload',
                    'message' => 'File uploading successfully.',
                ],
            ]);
        }
    }
 
}