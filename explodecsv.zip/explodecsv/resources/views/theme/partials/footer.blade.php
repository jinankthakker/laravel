<div class="text-center">
  2016 - Altumcore Technology
  <a href="index.html#" class="go-top">
      <i class="fa fa-angle-up"></i>
  </a>
</div>