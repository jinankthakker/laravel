<?php
namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Core\Configure;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\ORM\Table;
use Cake\ORM\TableRegistry;

class ProductsController extends AppController{

	 public function index() {
        $this->set('title', "Products");
        $this->viewBuilder()->layout('admin');
        $limit = 10;
        $conditions = array();
        if (isset($_GET['q']) && !empty($_GET['q'])) {
            $q = $_GET['q'];
            $int_q = preg_replace('/\D/', '', $q);
            $int_q = (!empty($int_q)) ? number_format($int_q) : "";
            $conditions['or']['Products.name like'] = "%" . trim($q) . "%";
            $conditions['or']['Products.sku like'] = "%" . trim($q) . "%";            
            $conditions['or']['Categories.name like'] = "%" . trim($q) . "%";
            }            
        if (isset($_GET['limit']) && !empty($_GET['limit'])) {
            $limit = $_GET['limit'];
        }
        $conditions['Products.is_delete'] = 0;       

        $this->paginate = [
            'limit' => $limit,
            'conditions' => $conditions,
            'order' => [
                'Products.id' => 'asc'
            ],
            'contain' => ['Categories']
        ];

        $products = $this->paginate();//        
        $this->set('products', $products);
    }

    public function add() {
        $this->set('title', "Add Product");
        $this->viewBuilder()->layout('admin');
        $this->Colors = TableRegistry::get("Colors");       
        $colors=$this->Colors->find('list')->toArray();
        $this->set('colors', $colors);
        if ($this->request->is('post')) {
        	$this->request->data['active']=1;
            if ($this->Products->saveData($this->request->data)) {
                $this->Flash->success(__('The Product has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('Unable to add the Product.'));
        }
        $product = $this->Products->newEntity();
        $this->set('product', $product);
        $categories = $this->__getCategories();
        $this->set('categories', $categories);
    }

    public function edit($id = null) {
        $this->set('title', "Edit Product");
        $this->viewBuilder()->layout('admin');
        $this->Colors = TableRegistry::get("Colors");       
        $colors=$this->Colors->find('list')->toArray();
        $this->set('colors', $colors);   
        $product = $this->Products->get($id,[
        'contain' => ['ProductColors']]);        
        if(!empty($product->product_colors)){
        foreach ($product->product_colors as $key => $value) {
            $color_old[]=$value['color_id'];
        }
        }else{
            $color_old=array();
        }      
         $this->set('color_old', $color_old);  

        if ($this->request->is(['post', 'put'])) {
            $data = $this->request->data;
            if ($this->Products->saveData($data)) {
                $this->Flash->success(__('Your channel has been updated.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('Unable to update your channel.'));
        }

        $this->set('product', $product);

        $categories = $this->__getCategories();
        $this->set('categories', $categories);
    }
    public function view($product_id = null) {
        $this->viewBuilder()->layout('ajax');
        $product_id = base64_decode($product_id);                
        
        $product = $this->Products->find('all', [
                    'conditions' => ['Products.id' => $product_id],
                    'contain' => ['Categories']
                ])
                ->first()
                ->toArray();        
        $this->set('product', $product);
    }
    public function activedeactive($id = null, $state = null) {
        $this->viewBuilder()->layout('ajax');
        $product = $this->Products->get($id);   
        $productData['active'] = ($state === 'true' ) ? 1 : 0;   
        $this->Products->patchEntity($product, $productData);

        if ($result = $this->Products->save($product)) {
            if ($state == "true")
                echo "Product has been Activated.";
            else
                echo "Product has been Deactivated.";
            exit;
        }
        else {
            echo 'error!!';
            exit;
        }
    }
     public function delete($id = null) {
        $this->viewBuilder()->layout('ajax');
        $query = $this->Products->query();
        $query->update()
                ->set(['is_delete' => 1])
                ->where(['id' => $id])
                ->execute();
        echo "Product has been successfully deleted.";
        exit;
    }
}