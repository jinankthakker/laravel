<!DOCTYPE html>
<html lang="en">
  <head>
    <?php echo $__env->make('theme.partials.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </head>

  <body>

  <section id="container" >      
      <!--header start-->
      <header class="header black-bg">
          <?php echo $__env->make('theme.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
      </header>
      <!--header end-->      
      
      <!--sidebar start-->
      <aside>
          <?php echo $__env->make('theme.partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </aside>
      <!--sidebar end-->     
     
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">

              <div class="row">
                  <?php echo $__env->yieldContent('content'); ?>
              </div><! --/row -->
          </section>
      </section>

      <!--main content end-->
      <!--footer start-->
     <!--  <footer class="site-footer">
          <?php echo $__env->make('theme.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </footer> -->
      <!--footer end-->
  </section>

           <?php echo $__env->make('theme.partials.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- js placed at the end of the document so the pages load faster -->
    
    <?php if(Session::has('messages')): ?>
    <script>
    jQuery(document).ready(function() {
      <?php foreach(Session::get('messages') AS $msg): ?>
      $.notify({
          title: '<?php echo e($msg['title']); ?>',
          message: '<?php echo e($msg['message']); ?>.'
        },{
          type: '<?php echo e($msg['type']); ?>'
        });       
      <?php endforeach; ?>
    });
    </script>
  <?php endif; ?>

  </body>
</html>
