<?php

namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\ORM\Table;
use Cake\ORM\TableRegistry;

class DashboardsController extends AppController{

	public function front(){
		$this->set('title', "Dashboard");
		$this->viewBuilder()->layout('admin');
		$user=$this->Auth->User();
		$this->set(compact('user'));

		$this->Products = TableRegistry::get("Products");
		$product = $this->Products->find()->where(['active' => 1])->count();
		$this->set('product',$product);

		$this->Orders = TableRegistry::get("Orders");
		$order = $this->Orders->find()->count();
		$this->set('order',$order);

		$this->Categories = TableRegistry::get("Categories");
		$Categories = $this->Categories->find()->where(['is_active' => 1])->count();
		$this->set('category',$Categories);

		$this->Users = TableRegistry::get("Users");
		$user = $this->Users->find()->where(['active' => 1])->count();
		$this->set('user',$user);
	}

}
