<?php

// src/Model/Table/ArticlesTable.php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Auth\DefaultPasswordHasher;
use App\Model\Table\AppTable;

class UsersTable extends AppTable {

    public function initialize(array $config) {
        parent::initialize($config);
        $this->belongsTo('Countries'); 
        $this->hasMany('UserAddresses');    
    }

    public function saveData($data) {

       /* if (isset($data['profile'])) {
            $data['profile'] = $this->__uplaodfiles($data['profile'], "upload/", 1);
            if (empty($data['profile']))
                unset($data['profile']);
        }*/

        $users = $this->newEntity();
        foreach ($data as $key => $value) {
            $users->{$key} = $value;
        }
        if ($this->save($users))
            return 1;
        else
            return 0;
    }
     public function saveData2($data) {

       /* if (isset($data['profile'])) {
            $data['profile'] = $this->__uplaodfiles($data['profile'], "upload/", 1);
            if (empty($data['profile']))
                unset($data['profile']);
        }*/

        $users = $this->newEntity();
        foreach ($data as $key => $value) {
            $users->{$key} = $value;
        }
        if ($this->save($users))
            return $users;
        else
            return 0;
    }

    public function getUserDetailField($field_name, $value) {
        $conditions = array();
        $conditions['Users.' . $field_name] = $value;
        $query = $this->find('all')->where($conditions);
        $userdataobj = $query->first();

        return $userdataobj;
    }

    public function checkPassword($passedPassword, $actualPassword) {
        if ((new DefaultPasswordHasher)->check($passedPassword, $actualPassword)) {
            return true;
        } else {
            return false;
        }
    }

    public function getEncryptedPassword($password) {
        if (strlen($password) > 0) {
            return (new DefaultPasswordHasher)->hash($password);
        }
    }

    public function UpdateData($id, $data) {
        if (isset($data['facebook_profile'])) {
            $data['facebook_profile'] = $this->__uplaodfiles($data['facebook_profile'], "upload/", 1);
            if (empty($data['facebook_profile']))
                unset($data['facebook_profile']);
        }
        // echo '<pre>'; print_r(base_url.$data['facebook_profile']); die;
        $users = $this->get($id);
        foreach ($data as $key => $value) {
            $users->{$key} = $value;
        }
        if ($this->save($users))
            return $users->id;
        else
            return 0;
    }

}

?>