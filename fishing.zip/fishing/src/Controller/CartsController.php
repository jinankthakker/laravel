<?php
namespace App\Controller;
use Cake\Event\Event;
use Cake\Core\Configure;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\ORM\Table;
use Cake\ORM\TableRegistry;

class CartsController extends AppController{

    /*public $components = array('Paypal');*/

    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $this->Auth->allow(['product']);
    }
    public function index(){
    	  $this->set('title', "Cart");
        $this->viewBuilder()->layout('front_layout');
        $this->UserAddresses = TableRegistry::get("UserAddresses");  
        $this->Colors = TableRegistry::get("Colors");       
        $colors=$this->Colors->find('list')->toArray();
        $this->set('colors', $colors);
        $cart_items=$this->Carts->find('all',array('conditions'=>array('Carts.user_id'=>$this->Auth->user('id')),"contain"=>['Products']))->toArray();        
        $this->set('cart_items', $cart_items);
        $useraddress=$this->UserAddresses->find('all',array('conditions'=>['UserAddresses.user_id'=>$this->Auth->user('id')]))->toArray(); 
        $this->set('useraddress', $useraddress);
    }
    public function checkout(){
        $this->set('title', "Cart");
        $this->viewBuilder()->layout('front_layout');
        $this->UserAddresses = TableRegistry::get("UserAddresses");  
        $this->States=TableRegistry::get("States");
        $state_codes=$this->States->find('list'); 
        foreach ($state_codes as $key=>$value) {
                 $state[$value]=$value;
               }       
        $this->set('state',$state);        
        $useraddress=$this->UserAddresses->find('all',array('conditions'=>['UserAddresses.user_id'=>$this->Auth->user('id'),'is_delete'=>0]))->toArray(); 
        $this->set('useraddress', $useraddress);
        $useraddresses = $this->UserAddresses->newEntity();       
        if ($this->request->is('post')) {
          $data=$this->request->data;
          $data['postcode']=$data['postpin'];
          $data['user_id']=$this->Auth->user('id');
          $user_address=$this->UserAddresses->patchEntity($useraddresses,$data);
          if($this->UserAddresses->save($user_address)){
              $this->Flash->success(__('Your Address has been updated.'));
              return $this->redirect(['action' => 'checkout']);
          }
        }
         $this->set('useraddresses', $useraddresses);    
    }
    public function updateQty($id,$qty){
    	$this->set('title', "Cart");
      $this->viewBuilder()->layout('ajax');
		  $data['id']=$id;
        $data['qty']=$qty;
           if($this->Carts->saveData($data)){
           		echo $qty;
           		exit;
           }
           exit;
    }
    public function deleteItem($id){
      $entity = $this->Carts->get($id);
      $result = $this->Carts->delete($entity);
      echo $result;
      exit;
    }
    public function deleteAddress($id){
      $this->UserAddresses = TableRegistry::get("UserAddresses"); 
      $entity = $this->UserAddresses->get($id);
      $query = $this->UserAddresses->query();
          $result=$query->update()
                ->set(['is_delete' =>1])
                ->where(['id' => $entity->id])
                ->execute();
      $this->Flash->success(__('Your Address has been deleted.'));
      return $this->redirect(['action' => 'checkout']);

    }
   public function paycheckout($id=null) {
      $this->set('title', "payCheckout");
      $this->viewBuilder()->layout('');   
      $this->Orders = TableRegistry::get("Orders");
      $this->OrderItems = TableRegistry::get("OrderItems"); 
       $this->UserAddresses = TableRegistry::get("UserAddresses");   
      $address=$this->UserAddresses->get($id);
      $this->set('address',$address);
      $cart=$this->Carts->find('all',['conditions'=>['Carts.user_id'=>$this->Auth->user('id')]])->toArray();
      if(empty($cart)){
         $this->Flash->error(__('Your Cart Is Empty!.'));
        return $this->redirect(['controller'=>'carts','action' => 'index']);
      }
      $cart_items=$this->Carts->find('all',array('conditions'=>array('Carts.user_id'=>$this->Auth->user('id')),"contain"=>['Products']))->toArray();
      $this->set('cart_items', $cart_items);
     
        $total=0;
        foreach ($cart_items as $key => $value) {
          if($value['product']['qty']!=0){
           if($value['product']['qty']>$value['qty'] || $value['product']['qty']==$value['qty'] ){  
           $total=$total+$value['product']['price'] * $value['qty'];   
           }else{
             $this->Flash->error(__('Not enough product quantity.'));
             return $this->redirect(['controller'=>'carts','action' => 'index']);
           } 
          }   
        } 
        $order=$this->Orders->newEntity(); 
        $order->user_id=$this->Auth->user('id');      
        $order->sub_total=$total;
        $order->shipping=0;
        $order->discount=0;
        $order->total=$total;
        $order->payment_methoad="PayPal";
        $order->order_address_id=$id;
        $orders=$this->Orders->save($order); 
        $this->set('orders', $orders);        
        $orderid=$orders->id;
        foreach ($cart_items as $key => $value) {
           $order_items=$this->OrderItems->newEntity();   
           $order_items->order_id= $orderid;
           $order_items->user_id= $this->Auth->user('id');; 
           $order_items->product_id= $value['product']['id']; 
           $order_items->qty= $value['qty']; 
           $order_items->color_id= $value['color']; 
           $order_items->price= $value['product']['price'] * $value['qty'];
           $order_item=$this->OrderItems->save($order_items);
        } 
        
      
    }
    public function success($id){      
      
      $transaction_id   = $_REQUEST['txn_id']; // Paypal transaction ID
      $grossamt         = $_REQUEST['payment_gross']; // Paypal received amount
      $paymeny_status     = $_REQUEST['payment_status']; // Paypal received currency type      

      //Rechecking the product price and currency details
      if($paymeny_status=="Completed")
      {
        $this->Orders = TableRegistry::get("Orders");
        $this->OrderItems = TableRegistry::get("OrderItems");
        $this->Products = TableRegistry::get("Products");
         $this->UserAddresses = TableRegistry::get("UserAddresses");
        
        $order_data['id']=$id;
        $order_data['order_no']=$this->__generate_order_id(6);
        $order_data['status']="Processing";
        $order_data['transaction_id']=$transaction_id;
        $order=$this->Orders->saveData($order_data);
        $orderItems_data['status']="Processing";
        $orderitems=$this->OrderItems->find('all',array('conditions'=>['order_id'=>$id,'user_id'=>$this->Auth->user('id')],'contain'=>['Products']));  
         $order=$this->Orders->get($id);
         $address=$this->UserAddresses->get($order->order_address_id);
          $emailorder="Hello ". $address->name.",<br/> Your  orderno is <b> #".$order->order_no."</b>.<br/> Your Purchase: <br/>
          <div  style='float:left;width:40%;background-color:#E5E5E5;margin:10px;padding:10px;'>
          <b>Company Address:</b><br/>
          The Fish Grip and More ,<br/>
          P.O. Box 720206,<br/>
          Jackson, MS 39272 .<br/>
          Tel:1-478-5088<br/>
          Email: customerservice@thefishgripandmore.com<br/>
          U.S.A.<br/>
          </div>
          <div style='float:left;width:40%;background-color:#E5E5E5;margin:10px;padding:10px;'>
          <b>Shipping Address</b><br/>
          ". $address->name.",<br/>
          ". $address->address1.",<br/>
          ". $address->address2." .<br/>
          Tel:". $address->phonr."<br/>
          city:". $address->city."<br/>
          State:". $address->state."<br/>
          U.S.A.<br/>
          </div>
            <table style='width:90%;margin:10px;padding:10px'>
            <tr style='background:#eee;'>
                <td ><b>Sr. No.</b></td>
                <td><b>Product</b></td>
                <td><b>Quantity</b></td>
                <td><b>Item SKU</b></td>
                <td><b>Rate</b></td>
                <td><b>Total</b></td>
            </tr>
          ";               
        foreach ($orderitems as $key => $value) {
          $i=1; $total=0; foreach($orderitems as $key =>$value) {
            $total=$total+$value["product"]["price"] * $value["qty"];
          $orderItems_data['id']=$value->id;
          $order_item=$this->OrderItems->saveData($orderItems_data); 
          $product=$this->Products->get($value->product->id);
          $newqty=$product->qty - $value->qty;
          $query = $this->Products->query();
          $result=$query->update()
                ->set(['qty' =>$newqty])
                ->where(['id' => $value->product->id])
                ->execute(); 
          $cart_item=$this->Carts->find('all',array('conditions'=>['Carts.product_id'=>$value->product_id,'Carts.user_id'=>$this->Auth->user('id')]))->first();  
                
          $entity = $this->Carts->get($cart_item->id);
          $result = $this->Carts->delete($entity);         
          
           $emailorder.='<tr>
                <td>'. $i.'</td>
                <td>'. $value->product->name .'</td>
                <td >'. $value["qty"].'</td>
                <td >'. $value->product->sku.'</td>
                <td style="width:15%;" >'. $value->product->price .'</td>
                <td>'. $value["qty"] * $value->product->price .'</td>
            </tr>';
            $i++ ;}         
            
          /*$wish_item=$this->Carts->find('all',array('conditions'=>['Wishlists.product_id'=>$value->product_id,'Wishlists.user_id'=>$this->Auth->user('id')]))->first();          
          $entity1 = $this->Wishlists->get($wish_item->id);
          $result2 = $this->Wishlists->delete($entity1);       */  
        }
         $emailorder.='<tr>
                <td colspan="3"></td>
                <td></td>
                <td></td>
            </tr>
             
            <tr>
                <td colspan="3"></td>
                <td><b>Total :</b></td>
                <td ><b>'.$total.'</b> </td>
            </tr>
        </table><br/><b>Thank you,<br/>The Fish Grip & MORE.</b> ';
        $this->Mailer->send_php_mail($this->Auth->user('username'),"Thank you for purchase",$emailorder);
        $this->Flash->success(__('Your Payment has been Paid.'));
        if($this->Auth->user('is_register')==1){
          return $this->redirect(['controller'=>'orders','action' => 'myorder']);
        }else{
          return $this->redirect(['controller'=>'carts','action' => 'index']);
        }
      }
      else
      {
        return $this->redirect(['controller'=>'pages','action' => 'index']);;
      }
    }    
    public function cancel($id=null){   

      $this->Flash->success(__('Error occurewd while transaction! Please try again later!'));
      return $this->redirect(['controller'=>'carts','action' => 'index']);
    }
      

}