<?php

// src/Model/Table/ArticlesTable.php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\ORM\TableRegistry;
use App\Model\Table\AppTable;

class OrderItemsTable extends AppTable {

    public function initialize(array $config) {
        parent::initialize($config);
        $this->belongsTo('Products');
        $this->belongsTo('Orders');
        $this->belongsTo('Users');
    }

    public function saveData($data) {
        $orderItems = $this->newEntity();
        foreach ($data as $key => $value) {
            $orderItems->{$key} = $value;
        }
        if ($this->save($orderItems))
            return 1;
        else
            return 0;
    }

}

?>