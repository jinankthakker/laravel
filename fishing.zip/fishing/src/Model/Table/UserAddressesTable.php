<?php

// src/Model/Table/ArticlesTable.php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\ORM\TableRegistry;
use App\Model\Table\AppTable;

class UserAdressesTable extends AppTable {

    public function initialize(array $config) {
        parent::initialize($config);
        $this->belongsTo('Users');       
        $this->belongsTo('Orders'); 
    } 

    public function saveData($data) { 
        $useraddress = $this->newEntity();
        foreach ($data as $key => $value) {
            $useraddress->{$key} = $value;
        }
        if ($this->save($useraddress))
            return 1;
        else
            return 0;
    }     

}

?>