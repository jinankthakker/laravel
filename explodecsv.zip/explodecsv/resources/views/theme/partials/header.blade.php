<div class="sidebar-toggle-box">
    <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
</div>
<!--logo start-->
<a href="index.html" class="logo"><b>Explodecsv</b></a>
<!--logo end-->            
<div class="top-menu">
	<ul class="nav pull-right top-menu">
        <!-- <li><a class="logout" href="login.html">Logout</a></li> -->
	</ul>
</div>