<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Network\Exception\NotFoundException;
use Cake\Auth\DefaultPasswordHasher;
use Cake\Core\Configure;
use Cake\ORM\Table;
use Cake\ORM\TableRegistry;
use Cake\Utility\Hash;
class UsersController extends AppController{

    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $this->Auth->allow(['registration','forgottenpassword','guest']);
    }

	public function login()
    {
        if(!$this->Auth->user()){        
            $this->set('title', "Login");
        	$this->viewBuilder()->layout('front_layout');
            $refer=$this->referer();
            $this->set('refer',$refer);
            if ($this->request->is('post')) {
                $redirect=$this->request->data['redirect'];
                $user = $this->Auth->identify();           
                if ($user){

                   if($user['role_id']==2 && $user['active']==1 && $user['email_verified']==1 ){
                        $this->Auth->setUser($user);
                        /*$this->Mailer->send_php_mail($user['email'],"Login","Succeesfully Logged in");*/
                         $this->Flash->success(__('Login Succeesfully!.')); 
                        return $this->redirect($redirect);
                    }elseif($user['active']==0){
                        $this->Flash->error(__('Please Activate Your Account!.')); 
                        return $this->redirect(array("controller"=>"Users","action"=>"Login"));
                    }elseif($user['email_verified']==0){
                        $this->Flash->error(__('Please Varify Your Account!.')); 
                        return $this->redirect(array("controller"=>"Users","action"=>"Login"));
                    }else{
                        $this->Flash->error(__('Please Try Again.')); 
                    }


                }
                else{
                $this->Flash->error(__('Invalid username or password, try again'));
                }
            }
        }else{
            return $this->redirect(array('action' =>'index','controller'=>'pages'));
        }
    }
    public function registration(){
        if(!$this->Auth->user()){   
            $this->set('title', "Registration");
            $this->viewBuilder()->layout('front_layout'); 
            if ($this->request->is('post')) {
                    $data = $this->request->data; 
                    $userfind=$this->Users->find('all',['conditions'=>['Users.username'=>$data['email'],'is_register'=>1]])->first();
                    if(!empty($userfind)){
                        $this->Flash->error(__('This email is already registered!'));
                        return $this->redirect(array('action' => 'login', 'controller' => 'users'));                   
                    }
                    $data['username']  =$data['email'];        
                    $data['password'] = $this->Users->getEncryptedPassword($data['password']);
                    $data['active'] = 1;
                    $data['role_id'] = 2;
                    $data['email_verified']=1;
                    $data['is_register']=1;
                    $site="http://" .$_SERVER['HTTP_HOST'];             
                    $emailregister="Hello,".$data['name']."<br/> You register at ".$site;
                    $user=$this->Users->saveData2($data);
                    if ($user) {
                            $this->Mailer->send_php_mail($data['email'],"Register",$emailregister);
                            $this->Flash->success(__('Succeesfully registerd!'));
                            $this->Auth->setUser($user);
                            return $this->redirect(array("controller"=>"pages","action"=>"index"));
                        }
                }  
            }else{
            return $this->redirect(array('action' =>'index','controller'=>'pages'));
        }    
    }
    public function guest($email){ 
        $data['email']=$email;
        $data['username']=$email;
        $data['active'] = 1;
        $data['role_id'] = 2;
        $data['email_verified']=1;
        $data['is_register']=0;
        $site="http://" .$_SERVER['HTTP_HOST'];
        $emailregister="<div style='background-color:E0EAF1' > Hello,<br>We are delighted that you have visited our website .<br/> You are login at <b>".$site."</b> as guest user.<br/><b>Thank You,<br/>The Fish Grip & More</b>";
        $user=$this->Users->saveData2($data);
        if ($user) {
                $this->Mailer->send_php_mail($data['email'],"Register",$emailregister);
                $this->Flash->success(__('Succeesfully registerd!'));
                $this->Auth->setUser($user);
                echo"1";
                exit;
            }

    }

    
    public function logout()
    {
        $this->Flash->success(__('Logout Succeesfully!.'));
        return $this->redirect($this->Auth->logout());

        
    }
    public function subscribe($email){
        $this->Subscribers = TableRegistry::get("Subscribers");
        $sub= $this->Subscribers->find('all',['conditions'=>['Subscribers.email'=>$email]])->first();
        if(empty($sub)){
            $data['email']=$email;
            $result=$this->Subscribers->saveData($data);
            echo"1";
            exit;   
        }else{
            echo"0";
            exit;
        }
        
    }

    public function  forgottenpassword(){
        $this->set('title', "Forget Password");
        $this->viewBuilder()->layout('front_layout'); 
        if ($this->request->is('post')) {
            $data=$this->request->data;
            $user=$this->Users->find('all',['conditions'=>['Users.username'=>$data['email']]])->first();
            if(!empty($user)){
               $userdata = $this->Users->get($user['id']);
                $pass=$this->__generate_order_id(8);
                $use['password'] = $this->Users->getEncryptedPassword($pass);
                $this->Users->patchEntity($userdata, $use);
                $login= $this->request->webroot."users/login";
                $emailpassword="Hello,".$userdata['name']."<br/> Your new password is ".$pass."<br/> Please Login and change your Password. <br/> Login : ".$login;
                if ($this->Users->save($userdata)) {
                    $this->Mailer->send_php_mail($data['email'],"Forget Password",$emailpassword);
                    $this->Flash->success(__('Please check your mail for new password.'));             
                    return $this->redirect(['action' => 'login']);
                } else {
                    $this->Flash->error(__('Unable to update user details.'));
                }

            }else{
               $this->Flash->error(__('This email is not registered!'));
               return $this->redirect(array('action' => ' forgottenpassword', 'controller' => 'users')); 
            }
        }

    }
    public function  changepassword(){
        $this->set('title', "Forget Password");
        $this->viewBuilder()->layout('front_layout'); 
        if($this->request->is('post')) {
           $data=$this->request->data;            
           $userdata = $this->Users->get($this->Auth->user('id'));
           $oldpass = $this->Users->checkPassword($data['oldpass'],$userdata['password']); 
           
            if($oldpass ==  1) {         
                $use['password'] = $this->Users->getEncryptedPassword($data['password']);
                $this->Users->patchEntity($userdata, $use);   
                if ($this->Users->save($userdata)) {                   
                    $this->Flash->success(__('Password changed successfully!'));             
                    return $this->redirect(['controller'=>'pages','action' => 'index']);
                } else {
                    $this->Flash->error(__('Unable to change password!'));
                }
            }else{
                $this->Flash->error(__('Please enter correct old password!'));
            }

        }       

    }

}
?>