<?php

// src/Model/Table/ArticlesTable.php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\ORM\TableRegistry;
use App\Model\Table\AppTable;

class WishlistsTable extends AppTable {

    public function initialize(array $config) {
        parent::initialize($config);    
         $this->belongsTo('Products');  
       }

    public function saveData($data) { 
        $carts = $this->newEntity();
        foreach ($data as $key => $value) {
            $carts->{$key} = $value;
        }
        if ($this->save($carts))
            return 1;
        else
            return 0;
    }   

}

?>