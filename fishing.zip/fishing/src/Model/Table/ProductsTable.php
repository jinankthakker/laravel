<?php

// src/Model/Table/ArticlesTable.php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\ORM\TableRegistry;
use App\Model\Table\AppTable;

class ProductsTable extends AppTable {

    public function initialize(array $config) {
        parent::initialize($config);
        $this->belongsTo('Categories');
        $this->hasMany('ProductColors', [
            'className' => 'ProductColors',
            'foreignKey' => 'product_id'
        ]);
        $this->hasMany('ProductImages', [
            'className' => 'ProductImages',
            'foreignKey' => 'product_id'
        ]);
        $this->hasMany('ProductReviews', [
            'className' => 'ProductReviews',
            'foreignKey' => 'product_id'
        ]);
       }

    public function saveData($data) {
         $this->ProductColors = TableRegistry::get('ProductColors');

        $data['slug'] = $this->__getslug($data['name'], $data['name']);

        if (isset($data['image'])) {
            $data['image'] = $this->__uplaodfiles($data['image'], "upload/products/", 1,263,263);
            if (empty($data['image']))
                unset($data['image']);
        }

        $products = $this->newEntity();
        foreach ($data as $key => $value) {
            $products->{$key} = $value;
        }
        if ($this->save($products)){ 
            $product_color_old=$this->ProductColors->find('all',['conditions'=>['ProductColors.product_id'=>$products->id]]);
            if(!$product_color_old->isEmpty()){
                foreach ($product_color_old as $key => $value) {
                    $entity1 = $this->ProductColors->get($value->id);
                    $result2 = $this->ProductColors->delete($entity1); 
                }
            }
             if(!empty($data['color_id'])){    
             foreach ($data['color_id'] as $key => $value) {
                $product_color = $this->newEntity();
                 $product_color['product_id']=$products->id;
                 $product_color['color_id']=$value;
                 $this->ProductColors->save($product_color);
             }
            }
            return 1;
        }
        else{
            return 0;
        }
    }

    public function __getslug($title = null, $slug = null) {
        $slug = strtolower(preg_replace('/[^A-Za-z0-9-]+/', '-', $slug));
        $pageslug = array();
        $pageslug = $this
                ->find()
                ->where(['slug' => $slug])
                ->first();

        if (!empty($pageslug)) {
            $i = 1;
            $flag = true;
            while ($flag) {
                $newslug = $slug . "-" . $i;
                $pageslug = array();
                $pageslug = $this
                        ->find()
                        ->where(['slug' => $newslug])
                        ->first();
                if (empty($pageslug)) {
                    $slug = $newslug;
                    $flag = FALSE;
                }
                $i++;
            }
        }
        return $slug;
    }

}

?>